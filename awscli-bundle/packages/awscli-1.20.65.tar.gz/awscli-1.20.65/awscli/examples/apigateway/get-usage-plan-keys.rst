**To get the list of API keys associated with a Usage Plan**

Command::

  aws apigateway get-usage-plan-keys --usage-plan-id a1b2c3
